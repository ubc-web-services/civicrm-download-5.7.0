<?php

namespace Civi\Api4;
use Civi\Api4\Generic\AbstractEntity;

/**
 * RelationshipType entity.
 *
 * @package Civi\Api4
 */
class RelationshipType extends AbstractEntity {

}
