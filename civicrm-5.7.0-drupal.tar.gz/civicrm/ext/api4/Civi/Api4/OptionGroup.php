<?php

namespace Civi\Api4;
use Civi\Api4\Generic\AbstractEntity;

/**
 * OptionGroup entity.
 *
 * @package Civi\Api4
 */
class OptionGroup extends AbstractEntity {

}
