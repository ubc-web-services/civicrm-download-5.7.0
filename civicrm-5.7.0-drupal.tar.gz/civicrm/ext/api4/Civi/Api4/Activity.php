<?php

namespace Civi\Api4;
use Civi\Api4\Generic\AbstractEntity;

/**
 * Activity entity.
 *
 * @package Civi\Api4
 */
class Activity extends AbstractEntity {

}
