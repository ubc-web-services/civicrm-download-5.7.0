<?php

namespace Civi\Api4;
use Civi\Api4\Generic\AbstractEntity;

/**
 * Contribution entity.
 *
 * @package Civi\Api4
 */
class Contribution extends AbstractEntity {

}
