<?php

namespace Civi\Api4;
use Civi\Api4\Generic\AbstractEntity;

/**
 * CustomField entity.
 *
 * @package Civi\Api4
 */
class CustomField extends AbstractEntity {

}
