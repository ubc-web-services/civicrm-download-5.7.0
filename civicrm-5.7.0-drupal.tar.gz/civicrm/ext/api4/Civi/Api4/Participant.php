<?php

namespace Civi\Api4;
use Civi\Api4\Action\Participant\Get;
use Civi\Api4\Generic\AbstractEntity;

/**
 * Participant entity.
 *
 * @method static Get get
 * @package Civi\Api4
 */
class Participant extends AbstractEntity {

}
