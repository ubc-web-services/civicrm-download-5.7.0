<?php

namespace Civi\Api4;
use Civi\Api4\Generic\AbstractEntity;

/**
 * OptionValue entity.
 *
 * @package Civi\Api4
 */
class OptionValue extends AbstractEntity {

}
