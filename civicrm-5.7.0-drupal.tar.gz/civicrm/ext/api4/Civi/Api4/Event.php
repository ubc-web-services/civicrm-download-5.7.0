<?php

namespace Civi\Api4;
use Civi\Api4\Generic\AbstractEntity;

/**
 * Event entity.
 *
 * @package Civi\Api4
 */
class Event extends AbstractEntity {

}
