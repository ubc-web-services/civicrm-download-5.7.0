<?php

namespace Civi\Api4;
use Civi\Api4\Generic\AbstractEntity;

/**
 * UFJoin entity - links profiles to the components/extensions they are used for.
 *
 * @package Civi\Api4
 */
class UFJoin extends AbstractEntity {

}
