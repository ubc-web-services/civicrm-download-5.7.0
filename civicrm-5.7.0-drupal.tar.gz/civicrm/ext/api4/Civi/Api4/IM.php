<?php

namespace Civi\Api4;
use Civi\Api4\Generic\AbstractEntity;

/**
 * IM entity.
 *
 * @package Civi\Api4
 */
class IM extends AbstractEntity {

}
