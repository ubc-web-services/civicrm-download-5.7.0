<?php

namespace Civi\Api4;
use Civi\Api4\Generic\AbstractEntity;

/**
 * Note entity.
 *
 * @package Civi\Api4
 */
class Note extends AbstractEntity {

}
