(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('api4', [
    'crmUi', 'crmUtil', 'ngRoute', 'ui.sortable'
  ]);
})(angular, CRM.$, CRM._);
