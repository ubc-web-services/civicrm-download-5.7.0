<?php

namespace Civi\Test\Api4\Utils;

use Civi\Test\Api4\Utils;


/**
 * Grandchild class
 *
 * This is an extended description.
 *
 * There is a line break in this description.
 *
 * @inheritDoc
 */
class TestV4ReflectionGrandchild extends Utils\TestV4ReflectionChild {

}
